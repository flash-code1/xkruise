<!DOCTYPE html>
<html class="wide wow-animation" lang="en">
  <head>
    <title>Taxi</title>
    <meta name="viewport" content="width=device-width height=device-height initial-scale=1.0">
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <link rel="icon" href="images/favicon.ico" type="image/x-icon">
    <link rel="stylesheet" type="text/css" href="//fonts.googleapis.com/css?family=Work+Sans:300,400,500,700%7CZilla+Slab:300,400,500,700,700i%7CGloria+Hallelujah">
    <link rel="stylesheet" href="css/bootstrap.css">
    <link rel="stylesheet" href="css/fonts.css">
    <link rel="stylesheet" href="css/style.css">
    <style>.ie-panel{display: none;background: #212121;padding: 10px 0;box-shadow: 3px 3px 5px 0 rgba(0,0,0,.3);clear: both;text-align:center;position: relative;z-index: 1;} html.ie-10 .ie-panel, html.lt-ie-10 .ie-panel {display: block;}</style>
  </head>
  <body>
    <div class="ie-panel"><a href="http://windows.microsoft.com/en-US/internet-explorer/"><img src="images/ie8-panel/warning_bar_0000_us.jpg" height="42" width="820" alt="You are using an outdated browser. For a faster, safer browsing experience, upgrade for free today."></a></div>
    <div class="preloader">
      <div class="preloader-logo"><a class="brand" href="index.html"><img class="brand-logo-dark" src="images/logo-default-355x118.png" alt="" width="177" height="59"/></a>
      </div>
      <div class="preloader-body">
        <div class="cssload-container">
          <div class="cssload-speeding-wheel"></div>
        </div>
      </div>
    </div>
    <div class="page">
      <!-- Page Header-->
      <!-- <a class="banner banner-top" href="https://www.templatemonster.com/website-templates/monstroid2.html" target="_blank"><img src="images/monstroid_02.jpg" alt="" height="0"/></a> -->
      <!-- Page Header-->
      <header class="page-header">
        <!-- RD Navbar-->
        <div class="rd-navbar-wrap">
          <nav class="rd-navbar rd-navbar-modern" data-layout="rd-navbar-fixed" data-sm-layout="rd-navbar-fixed" data-md-layout="rd-navbar-fixed" data-md-device-layout="rd-navbar-fixed" data-lg-layout="rd-navbar-static" data-lg-device-layout="rd-navbar-fixed" data-xl-layout="rd-navbar-static" data-xl-device-layout="rd-navbar-static" data-body-class="rd-navbar-modern-linked" data-lg-stick-up-offset="46px" data-xl-stick-up-offset="46px" data-xxl-stick-up-offset="46px" data-lg-stick-up="true" data-xl-stick-up="true" data-xxl-stick-up="true">
            <div class="rd-navbar-main-outer">
              <div class="rd-navbar-main">
                <div class="rd-navbar-nav-wrap">
                  <!-- RD Navbar Nav		-->
                  <ul class="rd-navbar-nav">
                    <li class="rd-nav-item active"><a class="rd-nav-link" href="index.php">Home</a>
                    </li>
                    <li class="rd-nav-item"><a class="rd-nav-link" href="services.php">Services</a>
                    </li>
                    <li class="rd-nav-item"><a class="rd-nav-link" href="typography.php">Typography</a>
                    </li>
                    <li class="rd-nav-item"><a class="rd-nav-link" href="contacts.php">Contacts</a>
                    </li>
                  </ul>
                </div>
                <!-- RD Navbar Search-->
                <div class="rd-navbar-search">
                  <button class="rd-navbar-search-toggle rd-navbar-fixed-element-1" data-rd-navbar-toggle=".rd-navbar-search"><span></span></button>
                  <form class="rd-search" action="#" data-search-live="rd-search-results-live" method="GET">
                    <div class="form-wrap">
                      <label class="form-label" for="rd-navbar-search-form-input">Search</label>
                      <input class="rd-navbar-search-form-input form-input" id="rd-navbar-search-form-input" type="text" name="s" autocomplete="off"/>
                      <div class="rd-search-results-live" id="rd-search-results-live"></div>
                    </div>
                    <button class="rd-search-form-submit fa-search" type="submit"></button>
                  </form>
                </div>
              </div>
            </div>
            <div class="rd-navbar-aside-outer">
              <div class="rd-navbar-aside">
                <!-- RD Navbar Panel-->
                <div class="rd-navbar-panel">
                  <!-- RD Navbar Toggle-->
                  <button class="rd-navbar-toggle" data-rd-navbar-toggle=".rd-navbar-nav-wrap"><span></span></button>
                  <!-- RD Navbar Brand-->
                  <div class="rd-navbar-brand"><a class="brand" href="index.php"><img class="brand-logo-dark" src="images/logo-default-355x118.png" alt="" width="177" height="59"/></a>
                  </div>
                </div>
                <div class="rd-navbar-collapse">
                  <button class="rd-navbar-collapse-toggle" data-rd-navbar-toggle=".rd-navbar-collapse-content"><span></span></button>
                  <div class="rd-navbar-collapse-content">
                    <div class="link-icon-title"><a class="link-icon-1" href="tel:#"><span class="icon mdi mdi-phone"></span><span>1-800-1234-567</span></a></div>
                    <div><a class="link-icon-1" href="mailto:#"><span class="icon mdi mdi-email-outline"></span><span>info@demolink.org</span></a></div>
                  </div>
                </div>
              </div>
            </div>
          </nav>
        </div>
      </header>
      <!-- FScreen-->
      <section class="section parallax-container section-xl bg-gray-900" data-parallax-img="images/bg-image-1.jpg">
        <div class="parallax-content">
          <div class="container">
            <div class="product-creative-main text-center">
              <p class="heading-1 product-creative-title"><a href="#">Reliable and Secure Way to Reach Any Point of the City</a></p>
              <div class="product-creative-text">
                <p class="heading-5 text-white"> We provide affordable and fast way to find a taxi when and where you need it.</p>
              </div>
              <p class="heading-2 product-creative-price text-primary"><a href="tel:#">1-800-1234-567</a></p><a class="button button-lg button-primary button-raven" href="book.php">order now</a>
            </div>
          </div>
        </div>
      </section>
      <!-- Counters-->
      <section class="section section-md bg-default">
        <div class="container">
          <div class="row row-50">
            <div class="col-6 col-md-3 wow fadeIn">
              <!-- Counter Modern-->
              <article class="counter-modern">
                <div class="icon counter-modern-icon mdi mdi-car"></div>
                <div class="counter-modern-main"><span>250</span><span></span></div>
                <h4 class="font-weight-regular counter-modern-title">Fleet Vehicles</h4>
              </article>
            </div>
            <div class="col-6 col-md-3 wow fadeIn" data-wow-delay=".2s">
              <!-- Counter Modern-->
              <article class="counter-modern">
                <div class="icon counter-modern-icon mdi mdi-account"></div>
                <div class="counter-modern-main">
                  <div class="counter">17</div>
                </div>
                <h4 class="font-weight-regular counter-modern-title">Drivers</h4>
              </article>
            </div>
            <div class="col-6 col-md-3 wow fadeIn" data-wow-delay=".2s">
              <!-- Counter Modern-->
              <article class="counter-modern">
                <div class="icon counter-modern-icon mdi mdi-coin"></div>
                <div class="counter-modern-main">
                  <div class="counter">231</div>
                </div>
                <h4 class="font-weight-regular counter-modern-title">Great Offers</h4>
              </article>
            </div>
            <div class="col-6 col-md-3 wow fadeIn" data-wow-delay=".2s">
              <!-- Counter Modern-->
              <article class="counter-modern">
                <div class="icon counter-modern-icon mdi mdi-flag-variant"></div>
                <div class="counter-modern-main">
                  <div class="counter">24</div><span>K</span>
                </div>
                <h4 class="font-weight-regular counter-modern-title">Annual Customers</h4>
              </article>
            </div>
          </div>
        </div>
      </section>
      <!-- Taxi Service App-->
      <section class="section section-lg bg-gray-100 bg-image bg-image-1" style="background-image: url(images/bg-image-2.jpg);">
        <div class="container">
          <div class="row">
            <div class="col-sm-9 col-md-8 col-lg-7 col-xl-6">
              <h2 class="wow fadeIn">Express Taxi App</h2>
              <p class="heading-5 wow fadeIn" data-wow-delay=".2s">Download our mobile app to make your taxi experience better than ever before!</p>
              <p class="wow fadeIn" data-wow-delay=".4s">Our brand new taxi app is now available for Android and iOS! With its help, you can fully customize your next taxi order. This includes selecting a driver as well as picking a type of car or any additional services that we offer.</p><a class="button button-lg button-primary button-raven wow fadeIn" data-wow-delay=".6s" href="#">Download Now</a>
            </div>
          </div>
        </div>
      </section>
      <!-- Testimonials-->
      <section class="section section-lg bg-default text-center">
        <div class="container">
          <h2 class="wow fadeIn">Testimonials</h2>
          <!-- Owl Carousel-->
          <div class="owl-carousel owl-style-1 wow fadeIn" data-wow-delay=".2s" data-items="1" data-dots="false" data-nav="true" data-stage-padding="0" data-loop="true" data-margin="30" data-animation-in="fadeIn" data-animation-out="fadeOut" data-autoplay="true" data-mouse-drag="false">
            <blockquote class="quote-light"><img class="quote-light-avatar" src="images/testimonials-4-68x68.jpg" alt="" width="68" height="68"/>
              <p class="heading-5 quote-light-cite">Brittany Grant</p>
              <p class="quote-light-position">Regular Client</p>
              <div class="quote-light-text">
                <p class="font-weight-regular heading-5">I found your service to be a 5-star experience. Our flight was delayed by two hours, so we arrived at the airport at 2am. However, the driver was waiting at the arrivals hall for us, when we finally got there. All the people we communicated with were pleasant and cheerful.</p>
              </div>
            </blockquote>
            <blockquote class="quote-light"><img class="quote-light-avatar" src="images/testimonials-1-68x68.jpg" alt="" width="68" height="68"/>
              <p class="heading-5 quote-light-cite">Patrick Mills</p>
              <p class="quote-light-position">Regular Client</p>
              <div class="quote-light-text">
                <p class="font-weight-regular heading-5">Everything went perfectly! Incredibly punctual, friendly drivers, and a very fast customer service that answered my questions within minutes the night before my return trip. I highly recommend booking here, and will definitely do so again in the future.</p>
              </div>
            </blockquote>
            <blockquote class="quote-light"><img class="quote-light-avatar" src="images/testimonials-2-68x68.jpg" alt="" width="68" height="68"/>
              <p class="heading-5 quote-light-cite">Paul Johnston</p>
              <p class="quote-light-position">Regular Client</p>
              <div class="quote-light-text">
                <p class="font-weight-regular heading-5">The service was excellent, thank you. My driver was waiting at Arrivals for me with a clear sign. He introduced himself, was very polite and friendly and drove me to my hotel with no delay. I will be pleased to recommend this service to my family and friends.</p>
              </div>
            </blockquote>
          </div>
        </div>
      </section>
      <!-- Our Advantages-->
      <section class="section section-lg text-center bg-gray-950">
        <div class="container">
          <h2 class="wow fadeIn">Our Advantages</h2>
          <div class="row row-30 justify-content-center">
            <div class="col-sm-6 col-lg-4 col-xl-3 wow fadeIn" data-wow-delay=".2s">
              <!-- Box Classic-->
              <article class="box-classic"><a class="icon box-classic-icon fl-bigmug-line-map87" href="#"></a><a class="box-classic-main" href="#">
                  <h4 class="box-classic-title">Local Routes</h4>
                  <p>We guarantee full taxi availability on any route in the city.</p></a></article>
            </div>
            <div class="col-sm-6 col-lg-4 col-xl-3 wow fadeIn" data-wow-delay=".3s">
              <!-- Box Classic-->
              <article class="box-classic"><a class="icon box-classic-icon fl-bigmug-line-planetary2" href="#"></a><a class="box-classic-main" href="#">
                  <h4 class="box-classic-title">Abroad Travels</h4>
                  <p>When traveling abroad, you can also benefit from using our taxi.</p></a></article>
            </div>
            <div class="col-sm-6 col-lg-4 col-xl-3 wow fadeIn" data-wow-delay=".4s">
              <!-- Box Classic-->
              <article class="box-classic"><a class="icon box-classic-icon fl-bigmug-line-portfolio23" href="#"></a><a class="box-classic-main" href="#">
                  <h4 class="box-classic-title">Business Travels</h4>
                  <p>Express offers the best taxi services to traveling businessmen.</p></a></article>
            </div>
            <div class="col-sm-6 col-lg-4 col-xl-3 wow fadeIn" data-wow-delay=".5s">
              <!-- Box Classic-->
              <article class="box-classic"><a class="icon box-classic-icon fl-bigmug-line-headphones32" href="#"></a><a class="box-classic-main" href="#">
                  <h4 class="box-classic-title">24/7 Online Support</h4>
                  <p>Our qualified staff offers professional 24/7 support to all clients.</p></a></article>
            </div>
          </div>
        </div>
      </section>
      <!-- Blog-->
      <section class="section section-lg bg-default text-center">
        <div class="container">
          <h2 class="wow fadeIn">Blog</h2>
          <div class="row row-40 justify-content-center">
            <div class="col-md-6 wow fadeIn">
              <!-- Post Classic-->
              <article class="post-classic"><a class="post-classic-media" href="#"><img class="post-classic-image" src="images/classic-blog-1-570x380.jpg" alt="" width="570" height="380"/></a>
                <div class="post-classic-meta">
                  <div class="badge">News</div>
                  <time datetime="2019">July 11, 2019 at 10:41 am </time>
                </div>
                <h4 class="font-weight-regular post-classic-title"><a href="#">Finding Lost Property: Tips from Express on How to Find Things That You’ve Lost in a Taxi</a></h4>
                <p>After an outing, you decide to catch a cab. You get home only to discover that you lost something really important in your taxi. Most people won’t bother to try to find the item. We...</p><a class="button button-link button-lg" href="#">Continue Reading</a>
              </article>
            </div>
            <div class="col-md-6 wow fadeIn" data-wow-delay=".2s">
              <!-- Post Classic-->
              <article class="post-classic"><a class="post-classic-media" href="#"><img class="post-classic-image" src="images/classic-blog-2-570x380.jpg" alt="" width="570" height="380"/></a>
                <div class="post-classic-meta">
                  <div class="badge">News</div>
                  <time datetime="2019">July 11, 2019 at 10:41 am </time>
                </div>
                <h4 class="font-weight-regular post-classic-title"><a href="#">Your #1 Guide On Selecting a Taxi Service for Business or Entertainment Trips in the United States</a></h4>
                <p>A taxi is an essential component of the public transportation system. Whether you are calling a taxi to your home or office on a regular basis, or are visiting a strange city and need...</p><a class="button button-link button-lg" href="#">Continue Reading</a>
              </article>
            </div>
          </div><a class="button button-lg button-primary button-raven wow fadeIn mt-40" href="#">View all Blog Posts</a>
        </div>
      </section>
      <!-- Page Footer--><a class="banner" href="https://www.templatemonster.com/website-templates/monstroid2.html" target="_blank"><img src="images/monstroid_big_02.jpg" alt="" height="0"/></a>
      <footer class="section footer-modern bg-gray-950">
        <div class="footer-modern-main">
          <div class="container">
            <div class="row row-50 justify-content-center justify-content-lg-between">
              <div class="col-md-6 col-lg-4">
                <h4 class="font-weight-regular footer-modern-title">Twitter Feed</h4>
                <!-- RD Twitter Feed-->
                <div class="twitter twitter-thin-group" data-twitter-username="templatemonster" data-twitter-date-hours=" hours ago" data-twitter-date-minutes=" minutes ago">
                  <article class="tweet-thin" data-twitter-type="tweet">
                    <div class="icon tweet-thin-icon fa-twitter"></div>
                    <div class="tweet-thin-main">
                      <p>Brave #Theme - Multipurpose #HTML Website Template - https://goo.gl/pzJx6G #webdesign</p>
                      <p class="text-white-dark">2 days ago</p>
                    </div>
                  </article>
                  <article class="tweet-thin" data-twitter-type="tweet">
                    <div class="icon tweet-thin-icon fa-twitter"></div>
                    <div class="tweet-thin-main">
                      <div class="tweet-thin-text" data-tweet="text">
                        <p>It is Proved That the #Discount Can Cheer You Up! Catch a Chance to Save 35% OFF Any #HTML Template!</p>
                        <p class="text-white-dark">2 days ago</p>
                      </div>
                    </div>
                  </article>
                  <article class="tweet-thin" data-twitter-type="tweet">
                    <div class="icon tweet-thin-icon fa-twitter"></div>
                    <div class="tweet-thin-main">
                      <div class="tweet-thin-text" data-tweet="text">
                        <p>Easy Steps to Create Cool #Vector Art on Your #iPhone https://goo.gl/QH3xAc</p>
                        <p class="text-white-dark">2 days ago</p>
                      </div>
                    </div>
                  </article>
                </div>
              </div>
              <div class="col-md-6 col-lg-4">
                <h4 class="font-weight-regular footer-modern-title">Gallery</h4>
                <div class="grid-1" data-lightgallery="group">
                  <div class="grid-1-item"><a class="thumbnail-creative thumbnail-creative-2" href="images/footer-gallery-1-original.jpg" data-lightgallery="item">
                      <figure class="thumbnail-creative-media"><img class="thumbnail-creative-image" src="images/footer-modern-gallery-1-100x100.jpg" alt="" width="100" height="100"/>
                      </figure>
                      <div class="thumbnail-creative-overlay"></div></a></div>
                  <div class="grid-1-item"><a class="thumbnail-creative thumbnail-creative-2" href="images/footer-gallery-2-original.jpg" data-lightgallery="item">
                      <figure class="thumbnail-creative-media"><img class="thumbnail-creative-image" src="images/footer-modern-gallery-2-100x100.jpg" alt="" width="100" height="100"/>
                      </figure>
                      <div class="thumbnail-creative-overlay"></div></a></div>
                  <div class="grid-1-item"><a class="thumbnail-creative thumbnail-creative-2" href="images/footer-gallery-3-original.jpg" data-lightgallery="item">
                      <figure class="thumbnail-creative-media"><img class="thumbnail-creative-image" src="images/footer-modern-gallery-3-100x100.jpg" alt="" width="100" height="100"/>
                      </figure>
                      <div class="thumbnail-creative-overlay"></div></a></div>
                  <div class="grid-1-item"><a class="thumbnail-creative thumbnail-creative-2" href="images/footer-gallery-4-original.jpg" data-lightgallery="item">
                      <figure class="thumbnail-creative-media"><img class="thumbnail-creative-image" src="images/footer-modern-gallery-4-100x100.jpg" alt="" width="100" height="100"/>
                      </figure>
                      <div class="thumbnail-creative-overlay"></div></a></div>
                  <div class="grid-1-item"><a class="thumbnail-creative thumbnail-creative-2" href="images/footer-gallery-5-original.jpg" data-lightgallery="item">
                      <figure class="thumbnail-creative-media"><img class="thumbnail-creative-image" src="images/footer-modern-gallery-5-100x100.jpg" alt="" width="100" height="100"/>
                      </figure>
                      <div class="thumbnail-creative-overlay"></div></a></div>
                  <div class="grid-1-item"><a class="thumbnail-creative thumbnail-creative-2" href="images/footer-gallery-6-original.jpg" data-lightgallery="item">
                      <figure class="thumbnail-creative-media"><img class="thumbnail-creative-image" src="images/footer-modern-gallery-6-100x100.jpg" alt="" width="100" height="100"/>
                      </figure>
                      <div class="thumbnail-creative-overlay"></div></a></div>
                  <div class="grid-1-item"><a class="thumbnail-creative thumbnail-creative-2" href="images/footer-gallery-7-original.jpg" data-lightgallery="item">
                      <figure class="thumbnail-creative-media"><img class="thumbnail-creative-image" src="images/footer-modern-gallery-7-100x100.jpg" alt="" width="100" height="100"/>
                      </figure>
                      <div class="thumbnail-creative-overlay"></div></a></div>
                  <div class="grid-1-item"><a class="thumbnail-creative thumbnail-creative-2" href="images/footer-gallery-8-original.jpg" data-lightgallery="item">
                      <figure class="thumbnail-creative-media"><img class="thumbnail-creative-image" src="images/footer-modern-gallery-8-100x100.jpg" alt="" width="100" height="100"/>
                      </figure>
                      <div class="thumbnail-creative-overlay"></div></a></div>
                  <div class="grid-1-item"><a class="thumbnail-creative thumbnail-creative-2" href="images/footer-gallery-9-original.jpg" data-lightgallery="item">
                      <figure class="thumbnail-creative-media"><img class="thumbnail-creative-image" src="images/footer-modern-gallery-9-100x100.jpg" alt="" width="100" height="100"/>
                      </figure>
                      <div class="thumbnail-creative-overlay"></div></a></div>
                </div>
              </div>
              <div class="col-lg-4">
                <h4 class="font-weight-regular footer-modern-title">Get in Touch</h4>
                <!-- RD Mailform-->
                <form class="rd-form form-sm rd-mailform" data-form-output="form-output-global" data-form-type="contact" method="post" action="bat/rd-mailform.php">
                  <div class="form-wrap">
                    <input class="form-input" id="contact-form-name-3" type="text" name="name" data-constraints="@Required">
                    <label class="form-label" for="contact-form-name-3">Your name</label>
                  </div>
                  <div class="form-wrap">
                    <input class="form-input" id="contact-form-email-3" type="email" name="email" data-constraints="@Email @Required">
                    <label class="form-label" for="contact-form-email-3">E-mail</label>
                  </div>
                  <div class="form-wrap">
                    <label class="form-label" for="contact-form-message-3">Message</label>
                    <textarea class="form-input" id="contact-form-message-3" name="message" data-constraints="@Required"></textarea>
                  </div>
                  <div class="form-wrap">
                    <button class="button button-primary button-raven" type="submit">Send</button>
                  </div>
                </form>
              </div>
            </div>
          </div>
        </div>
        <div class="footer-modern-aside">
          <div class="container">
            <div class="layout-2">
              <!-- Rights-->
              <p class="rights"><span>&copy;&nbsp;</span><span class="copyright-year"></span>. All Rights Reserved. Design by <a href="#">Flint</a></p>
              <div>
                <div class="group group-middle"><a class="link-social-2 icon mdi mdi-facebook" href="#"></a><a class="link-social-2 icon mdi mdi-twitter" href="#"></a><a class="link-social-2 icon mdi mdi-google" href="#"></a><a class="link-social-2 icon mdi mdi-instagram" href="#"></a><a class="link-social-2 icon mdi mdi-linkedin" href="#"></a></div>
              </div>
            </div>
          </div>
        </div>
      </footer>
    </div>
    <div class="snackbars" id="form-output-global"></div>
    <script src="js/core.min.js"></script>
    <script src="js/script.js"></script>
  </body>
</html>